package com.example.nguyenvanhuyflutterapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NguyenvanhuyflutterapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(NguyenvanhuyflutterapiApplication.class, args);
	}

}
