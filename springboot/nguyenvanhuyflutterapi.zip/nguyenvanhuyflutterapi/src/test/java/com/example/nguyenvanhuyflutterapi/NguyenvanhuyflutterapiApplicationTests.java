package com.example.nguyenvanhuyflutterapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NguyenvanhuyflutterapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
